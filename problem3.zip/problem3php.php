<?php

class TestBoolean
{
    public function isBoolean($arr, $param)
    {
        $sum1 = $arr[0] + $arr[1] + $arr[2] + $arr[3];
        $sum2 = $arr[4] + $arr[5] + $arr[6] + $arr[7];

        if ($sum1 > $sum2) {
            $temp1 = $arr[1];
            $arr[1] = $arr[5];
            $arr[5] = $temp1;
            $temp2 = $arr[3];
            $arr[3] = $arr[7];
            $arr[7] = $temp2;
        } elseif ($sum1 < $sum2) {
            for ($i = 4; $i < count($arr); $i++) {
                for ($j = 0; $j < 4; $j++) {
                    $arrNew[$j] = $arr[$j] * $arr[$i];
                }
                $sum1 = $arrNew[0] + $arrNew[1] + $arrNew[2] + $arrNew[3];
                $sum2 = $arr[4] + $arr[5] + $arr[6] + $arr[7];
                if ($sum1 > $sum2) {
                    $arr[0] = $arrNew[0];
                    $arr[1] = $arrNew[1];
                    $arr[2] = $arrNew[2];
                    $arr[3] = $arrNew[3];
                    break;
                } else {
                    continue;
                }
                break;
            }
        }
        foreach ($arr as $val) {
            $finalArray[] = abs($val);
        }
        $palindrom = array_count_values($finalArray);
        $flag = false;
        $finalString = 0;
        foreach ($palindrom as $pal) {
            if ($pal % 2 == 0) {
                $flag = true;
            } else {
                $flag = false;
                $finalSum = array_sum($finalArray);
                $perfectSqur = $this->countSquares(100, $param);
                $finalString = $finalSum * $perfectSqur;
                break;
            }
        }
        return $flag;
    }

    public function countSquares($a = 100, $param)
    {
        if ($param > 999) {
            $param = 999;
        }
        $perfectSqur = [];
        for ($i = $a; $i <= $param; $i++)
            for (
                $j = 1;
                $j * $j <= $i;
                $j++
            ) {
                if ($j * $j == $i) {
                    $perfectSqur[] = $i;
                }
            }
        $lastdigit = $perfectSqur[count($perfectSqur) - 1];
        return $lastdigit;
    }
}
$obj = new TestBoolean();
echo $obj->isBoolean([1, 2, 3, 4, -1, -2, -3, -4], -1000);
