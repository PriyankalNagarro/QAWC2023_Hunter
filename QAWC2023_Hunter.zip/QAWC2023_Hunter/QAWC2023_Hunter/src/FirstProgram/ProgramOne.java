package FirstProgram;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.http.HttpClient.Factory;
import org.openqa.selenium.WebElement;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;


import org.openqa.selenium.By;
public class ProgramOne {
	public static void main(String[] args) throws FileNotFoundException{ 
		
    //Setting the driver path
	System.setProperty("webdriver.chrome.driver","\"C:\\Users\\nilanjana\\Downloads\\chromedriver.exe\""); 
	WebDriver driver = new ChromeDriver();
	driver.get("https://www.nagarro.com/");
	driver.manage().window().maximize();
	
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	//Common method
	Actions action = new Actions(driver);
	
	//Locating web element
			WebElement services = driver.findElement(By.xpath("//a[text()='services']"));
			WebElement aqte_Link = driver.findElement(By.xpath("(//a[contains(@href,'accelerated-quality')])[3]"));
			WebElement testAutoROICalc = driver.findElement(By.xpath("//h3[contains(text(),'Test Automation ROI Calculator')]"));
			WebElement findOutYouROI = driver.findElement(By.xpath("//span[contains(text(),'Find out your ROI')]"));
			WebElement letsFindOut = driver.findElement(By.id("startSurvey"));
			WebElement automationCandidate = driver.findElement(By.id("automationCandidates"));
			
			List<WebElement> nextBtn = driver.findElements(By.xpath("//a[contains(text(),'Next')]"));
			List<WebElement> calculateROI = driver.findElements(By.xpath("//a[contains(text(),'Calculate your ROI')]"));
			WebElement lastName = driver.findElement(By.xpath("//input[@name='lastname']"));
			WebElement companyName = driver.findElement(By.xpath("//input[@name='company']"));
			WebElement email = driver.findElement(By.xpath("//input[@name='email']"));
			WebElement submitBtn = driver.findElement(By.xpath("//input[@value='Submit']"));
			WebElement roiImprovementValue = driver.findElement(By.id("roiValue"));
			WebElement payBackPeriodValue = driver.findElement(By.id("paybackPeriod"));
			
			
	//Performing actions on webElements
			services.click();
			aqte_Link.click();
			action.moveToElement(testAutoROICalc);
			findOutYouROI.click();
			letsFindOut.click();
//			FileInputStream fis=new FileInputStream("\\testData.xlsx"); 
//			// Fetching value from excel sheet to enter
//			WorkbookFactory wb = WorkbookFactory.create(fis);
//			XSSFSheet sheet = workbook.getSheetAt(0);
//                        
//			Row row = sheet.getRow(0);
//			Cell cell = row.getCell(0);
//                      
//			System.out.println(sheet.getRow(0).getCell(0));
			
			
			automationCandidate.sendKeys(args);
			nextBtn.get(0).click();
			nextBtn.get(2).click();
			nextBtn.get(4).click();
			calculateROI.get(0).click();
			lastName.sendKeys("Random");
			companyName.sendKeys("Nagarro");
			email.sendKeys("nilanjana@nagarro.com");
			submitBtn.click();
			String ROIImprovementValue = roiImprovementValue.getText();
			String PayBackPeriodValue = payBackPeriodValue.getText();
			
			
	}
}
